import pandas as pd
import streamlit as st
from langchain.output_parsers import PydanticOutputParser
from langchain_anthropic import ChatAnthropic  # For ChatAnthropic
from pydantic import BaseModel, Field
from typing_extensions import TypedDict
from typing import List, Annotated, Optional, Union, Literal
from langgraph.graph import StateGraph, START, END
from langchain_community.document_loaders import PDFPlumberLoader
from pathlib import Path
from langgraph.graph import MessagesState
from langchain_core.messages import HumanMessage, SystemMessage, AIMessage
import json
from langgraph.checkpoint.memory import MemorySaver
from io import BytesIO, StringIO


from langchain_google_genai import ChatGoogleGenerativeAI
import os
from dotenv import load_dotenv
load_dotenv()
import google.generativeai as genai
genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))

os.environ['ANTHROPIC_API_KEY'] = os.getenv("ANTHROPIC_API_KEY")
#anthropic_api_key = os.getenv("ANTHROPIC_API_KEY")

class User(BaseModel):
    username: str = Field(..., description="Generated username")
    email: str = Field(..., description="User's email")
    designation: str = Field(..., description="User's designation in the company")
    department: str = Field(..., description="Department name")
    phone: str = Field(..., description="User phone details")

class Address(BaseModel):
    address1: str
    address2: Optional[str]
    city: str
    state: str
    zip: str
    country: Optional[str]
    county: Optional[str]

class Customer(BaseModel):
    id: int
    name: str
    address: Address

class Office(BaseModel):
    id: int
    location: str
    size: int

#llm = ChatGoogleGenerativeAI(model="models/gemini-1.5-flash", temperature=0.0)
llm = ChatAnthropic(model="claude-3-5-haiku-20241022", temperature=0.0)

class IntentEntityPath(BaseModel):
    intent: Literal["add", "delete", "general"] = Field(description="The classified intent: The input must specify something to add or delete in order to have intent as add or delete, everything else is general chat.")
    entity: Literal["user", "customer", 'office', 'N/A'] = Field(description="The classified entity. Applicable only when the intent is add or delete.")
    #addition_file_path: str = None
    delete_attribute: Optional[str] = None
    delete_value: Optional[str] = None

def detect_intent(state):
    "This node will detect intent"

    chat_input = state['messages'][-1].content
    response = llm.with_structured_output(IntentEntityPath).invoke(chat_input)

    return {
        #'file_path': response.addition_file_path, 
        'output_schema': response.entity, 
        'intent': response.intent,
        'delete_attribute': response.delete_attribute,
        'delete_value': response.delete_value}

def router(state) -> Literal['read_file', 'delete', 'general_chat']:
    if state['intent'] == 'add':
        return 'read_file'
    if state['intent'] == 'delete':
        return 'delete'
    if state['intent'] == 'general':
        return 'general_chat'


def read_file(state):
    "This node will read the file and extract data from the file path"
    file_path = state['file_path']
    file_ext = Path(file_path).suffix.lower()  # Convert to lowercase for consistent comparison

    if file_ext == '.csv':
        df = pd.read_csv(file_path)
        return {'file_content': df.to_dict(orient="records")}

    if file_ext == '.xlsx':
        df = pd.read_excel(file_path)
        return {'file_content': df.to_dict(orient="records")}

    if file_ext == '.pdf':
        try:
            loader = PDFPlumberLoader(file_path)
            content = loader.load()
            return {'file_content': content}
        except Exception as e:
            return {'file_content': [{"error": f"Failed to read PDF: {str(e)}"}]}
            
    if file_ext == '.json':
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                content = json.load(file)
                # If content is not a list, wrap it in a list for consistent processing
                if not isinstance(content, list):
                    content = [content]
                return {'file_content': content}
        except json.JSONDecodeError as e:
            return {'file_content': [{"error": f"Failed to parse JSON: {str(e)}"}]}
        except Exception as e:
            return {'file_content': [{"error": f"Failed to read JSON file: {str(e)}"}]}
            
    if file_ext == '.txt':
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                content = file.read()
                # Return content as a list with a single item for consistent processing
                return {'file_content': [{"text": content}]}
        except Exception as e:
            return {'file_content': [{"error": f"Failed to read text file: {str(e)}"}]}

    return {'file_content': [{"error": f"Failed to read file: {str(e)}", "suggestion": "File might be binary or corrupted"}]}

def interpret(state):

    prompt = f"""
    Given this raw user data: {state['file_content']}, extract and map it to the Entitylist format.
    Take appropriate instructions from the user input. User Input: {state['messages'][-1].content}
    """
    if state['output_schema'] == 'customer':
        class Entitylist(BaseModel):
            entities: list[Customer]

    if state['output_schema'] == 'user':
        class Entitylist(BaseModel):
            entities: list[User]

    if state['output_schema'] == 'office':
        class Entitylist(BaseModel):
            entities: list[Office]

    response = llm.with_structured_output(Entitylist).invoke(prompt)
    return {'result_json': response.entities}

def add(state):
    new_entities = state['result_json']
    new_entities_dicts = [entity.dict() for entity in new_entities]

    if state['output_schema'] == 'user':
        json_file_path = r'users.json'
        unique_key = 'username'
    elif state['output_schema'] == 'customer':
        json_file_path = r'customers.json'
        unique_key = 'id'
    elif state['output_schema'] == 'office':
        json_file_path = r'offices.json'
        unique_key = 'id'

    try:
        with open(json_file_path, 'r') as file:
            existing_data = json.load(file)
    except FileNotFoundError:
        # If file doesn't exist, create it with empty list
        existing_data = []

    # Create a dictionary of existing entities for efficient lookup
    existing_entities_dict = {str(entry[unique_key]): entry for entry in existing_data}
    
    # Process each new entity
    added_entities = []
    skipped_entities = []
    
    for entity in new_entities_dicts:
        entity_key = str(entity[unique_key])  # Convert to string for consistent comparison
        if entity_key in existing_entities_dict:
            skipped_entities.append(entity)
        else:
            added_entities.append(entity)
            existing_data.append(entity)

    # Generate appropriate message based on results
    message_parts = []
    if added_entities:
        message_parts.append(f"Successfully added {len(added_entities)} new {state['output_schema']}(s)")
        message_parts.append(f"Added {state['output_schema']}s with {unique_key}s: {[entity[unique_key] for entity in added_entities]}")
    
    if skipped_entities:
        message_parts.append(f"Skipped {len(skipped_entities)} existing {state['output_schema']}(s)")
        message_parts.append(f"Skipped {state['output_schema']}s with {unique_key}s: {[entity[unique_key] for entity in skipped_entities]}")
    
    if added_entities:
        # Only write to file if we actually added something
        with open(json_file_path, 'w') as file:
            json.dump(existing_data, file, indent=4)
    
    message = ". ".join(message_parts) + "."
    return {'messages': AIMessage(content=message)}

def delete(state):
    attribute = state['delete_attribute']
    value = state['delete_value']
    if state['output_schema'] == 'user':
        json_file_path = r'users.json'
    if state['output_schema'] == 'customer':
        json_file_path = r'customers.json'
        value = int(value)
    if state['output_schema'] == 'office':
        json_file_path = r'offices.json'
    try:
        with open(json_file_path, 'r') as file:
            data = json.load(file)
        
        # Filter out the entries that do not match the attribute value
        filtered_data = [entry for entry in data if entry.get(attribute) != value]
        
        with open(json_file_path, 'w') as file:
            json.dump(filtered_data, file, indent=4)
        
        print(f"Entries with {attribute} = {value} have been deleted.")
    except Exception as e:
        print(f"An error occurred: {e}")
    
    ai_message = AIMessage(content=f"Successfully deleted {state['output_schema']} with {attribute}: {value} from the database.")
    return {'messages': ai_message}

def general_chat(state):
    messages_state = state['messages']
    system_message = SystemMessage(content="You are an assitant. You can add, delete users, customers and offices in the database. If they ask for help, give examples like 'Add a new user from the file.' after uploading the file or 'Delete user with username: john_doe.'. Suggest the user that they must upload a file which contains information for adding users/customers/offices.")
    response = llm.invoke([system_message] + messages_state)
    return {'messages': response.content}

class GraphState(MessagesState):
    """
    Graph state is a dictionary that contains information we want to propagate to, and modify in, each graph node.
    """
    intent: str
    file_path: Optional[str]
    file_content: Optional[Union[dict, list, str]]
    raw_input: Optional[str]
    output_schema: Optional[str]
    result_json: Optional[dict]
    delete_attribute: Optional[str] = None
    delete_value: Optional[Union[str, int]] = None


