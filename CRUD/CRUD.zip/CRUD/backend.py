from fastapi import FastAPI
from langchain_core.messages import HumanMessage, SystemMessage, AIMessage
from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.memory import MemorySaver
from functions_models import detect_intent, read_file, interpret, add, delete, router, general_chat, GraphState
from pydantic import BaseModel
from typing import Union, Optional

app = FastAPI()

graph = StateGraph(GraphState)

graph.add_node("detect_intent", detect_intent)
graph.add_node("read_file", read_file)
graph.add_node("interpret", interpret)
graph.add_node("add", add)
graph.add_node("delete", delete)
graph.add_node("general_chat", general_chat)

graph.add_edge(START, "detect_intent")
graph.add_conditional_edges("detect_intent", router)
graph.add_conditional_edges("detect_intent", general_chat)
graph.add_edge("read_file", "interpret")
graph.add_edge("interpret", "add")
graph.add_edge("add", END)
graph.add_edge("delete", END)
graph.add_edge("general_chat", END)


checkpointer = MemorySaver()
config = {"configurable": {"thread_id": "1"}}
workflow = graph.compile(checkpointer=checkpointer)

class ChatInput(BaseModel):
    input_text: str
    file_path: Optional[str] = None

@app.post("/chat/")
async def chat(chat_input: ChatInput):
    chat_text = chat_input.input_text
    if chat_input.file_path is not None:
        output = workflow.invoke({
            'messages': HumanMessage(content=chat_text),
            'file_path': chat_input.file_path
            }, config)
    else: output = workflow.invoke({'messages': HumanMessage(content=chat_text)}, config)
    ai_message = output['messages'][-1].content
    return ai_message